 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 % Korus - http://code.google.com/p/korus
 % Copyright (C) 2009 Impetus Technologies, Inc.(http://www.impetus.com/)
 % This file is part of Korus.
 % Korus is free software: you can redistribute it and/or modify
 % it under the terms of the GNU General Public License version 3 as published
 % by the Free Software Foundation (http://www.gnu.org/licenses/gpl.html)
 % 
 % Korus is distributed in the hope that it will be useful,
 % but WITHOUT ANY WARRANTY; without even the implied warranty of
 % MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 % GNU General Public License for more details.
 %    
 % You should have received a copy of the GNU General Public License
 % along with Korus.  If not, see <http://www.gnu.org/licenses/>.
 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-module(test).
-export([go/0,callback/0]).

go()->
	Pid = spawn(test,callback, []),	
	register(callback, Pid),
	korusAdapter:connect("127.0.0.1"),

	D = dict:new(),
	D1 = dict:append("itemName", "phone", D),
	korusAdapter:send("buyProcess1",D1),
	ok.	
	
callback()->
	receive
		{response,ResponseObj} ->
			unregister(callback),
			D = dict:fetch(response,ResponseObj),
			io:format("Callback method - Response Payload  ~p",[D]),
			korusAdapter:disconnect()
	end,
	callback().

	

		
