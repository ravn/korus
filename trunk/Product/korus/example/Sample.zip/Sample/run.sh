rm -rf *.class
javac -classpath korus.jar @sourcefiles
java -classpath korus.jar:. TestProcess
